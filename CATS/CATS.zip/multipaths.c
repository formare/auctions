#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/* * Constants & Parameters **************************************** */
#define NUMGOODS 30
#define NUMBIDS 2000

int NUMCITIES = (int) (0.529689 * NUMGOODS + 3.4329);

#define INITIAL_CONNECTIONS 2
#define BUILDING_PENALTY 1.7
#define NUM_BUILDING_PATHS ((NUMCITIES) * (NUMCITIES) / 4)
#define SHIPPING_COST_FACTOR 1.5
#define MAX_BID_SET_SIZE 5

#define MAX_CAP 100
#define ADDITIVITY 0.2


/* Warn if you build a graph this many times without success*/
#define WARN_TRIES 10000

/* * Variable Definitions ****************************************** */

typedef struct { float x, y;} point;
point * cities;
double * * edges;
int * * edgesgood;
int numbids, numdummy;

int cap[NUMGOODS];
double capadd;

int * q, * pi;
double * d;

typedef struct edgeto { int city; float w; } edgeto;

typedef struct path { int * path, pathlen, capacity; double cost; } path;

path best_paths [MAX_BID_SET_SIZE];
int num_best_paths;
double maxcost;

#define LEEWAY MAX_BID_SET_SIZE

typedef struct bid_type {
  int * goods;
  int numgoods;
  int dummy;
  int numunits;
  double value;
} bid_type;

bid_type bids [NUMBIDS + LEEWAY];

/* typedef struct bid_list {
  bid_type bid;
  struct bid_list * next;
} bid_list;

bid_list * bids;
*/

#define INF 500000.0
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define sqr(x) ((x)*(x))

double RealDistance(int city1, int city2)
{
  return sqrt(sqr(cities[city2].x - cities[city1].x) +
             sqr(cities[city2].y - cities[city1].y));
}

double BuildingDistance(int u, int v)
{
  if (edges[u][v] < 0) return RealDistance(u, v) * BUILDING_PENALTY;
  else return edges[u][v];
}

void Initialize()
{
  int i;
  srand48(time(NULL));
  cities = (point *) malloc(sizeof(point) * NUMCITIES);
  if (cities == NULL) { printf("malloc error.\n"); exit(2); }
  edges = (double * *) malloc(sizeof(double *) * NUMCITIES);
  if (edges == NULL) { printf("malloc error.\n"); exit(2); }
  for (i = 0; i < NUMCITIES; i++)
  {
    edges[i] = (double *) malloc(sizeof(double) * NUMCITIES);
    if (edges[i] == NULL) { printf("malloc error.\n"); exit(2); }
  }
  edgesgood = (int * *) malloc(sizeof(int *) * NUMCITIES);
  if (edgesgood == NULL) { printf("malloc error.\n"); exit(2); }
  for (i = 0; i < NUMCITIES; i++)
  {
    edgesgood[i] = (int *) malloc(sizeof(int) * NUMCITIES);
    if (edgesgood[i] == NULL) { printf("malloc error.\n"); exit(2); }
  }
  q = (int *) malloc(sizeof(int) * NUMCITIES);
  if (q == NULL) { printf("malloc error.\n"); exit(2); }
  pi = (int *) malloc(sizeof(int) * NUMCITIES);
  if (pi == NULL) { printf("malloc error.\n"); exit(2); }
  d = (double *) malloc(sizeof(double) * NUMCITIES);
  if (d == NULL) { printf("malloc error.\n"); exit(2); }
  for (i = 0; i < NUMGOODS; i++) cap[i] = 1 + (lrand48() % MAX_CAP);
}

void Dispose()
{
  int i;
  free(cities);
  for (i = 0; i < NUMCITIES; i++)
  {
    free(edges[i]);
    free(edgesgood[i]);
  }
  free(edges);
  free(edgesgood);
  free(q);
  free(pi);
  free(d);
  for (i = 0; i < numbids; i++)
    free(bids[i].goods);
}

void DisplayGraph(char * edgefile, char * cityfile)
{
  int i, j;
  FILE * fp;

  fp = fopen(edgefile, "w");
  if (fp == NULL)
  {
    printf("error opening display file for writing\n");
    exit(2);
  }
  for (i = 0; i < NUMCITIES; i++)
  for (j = 0; j < NUMCITIES; j++)
  if (!(edges[i][j] < 0))
    fprintf(fp, "%f %f\n%f %f\n\n", cities[i].x, cities[i].y,
              cities[j].x, cities[j].y);
  fclose(fp);

  fp = fopen(cityfile, "w");
  if (fp == NULL)
  {
    printf("error opening display file for writing\n");
    exit(2);
  }
  for (i = 0; i < NUMCITIES; i++)
    fprintf(fp, "%f %f\n", cities[i].x, cities[i].y);
  fclose(fp);
}


void Good2Edge(int g, int *c1, int *c2)
{
  int i, j;
  *c1 = -1; *c2 = -1;
  for (i = 0; i < NUMCITIES; i++)
  for (j = 0; j < NUMCITIES; j++)
    if (edgesgood[i][j] == g) { *c1 = i; *c2 = j; return ; }
}


void DisplayBid(char * edgefile, bid_type b)
{
  int i, c1, c2;
  FILE * fp;

  fp = fopen(edgefile, "w");
  if (fp == NULL)
  {
    printf("error opening display file for writing\n");
    exit(2);
  }
  for (i = 0; i < b.numgoods; i++)
  {
    Good2Edge(b.goods[i], &c1, &c2);
    fprintf(fp, "%f %f\n%f %f\n\n", cities[c1].x, cities[c1].y,
              cities[c2].x, cities[c2].y);
  }
  fclose(fp);
}


void Relax(int u, int v, double w, double * d, int * pi)
{
  if (d[v] > d[u] + w)
  {
    d[v] = d[u] + w;
    pi[v] = u;
  }
}

int ExtractMin(int * q, int * qsize, double * d)
{
  int i, besti = -1, b;
  double bestval = INF;
  for (i = 0; i < (*qsize); i++)
  if (d[q[i]] < bestval)
  {
    besti = i;
    bestval = d[q[i]];
  }
  b = q[besti];
  q[besti] = q[(*qsize)-1];
  (*qsize)--;
  return b;
}

void ConstructPath(int s, int t, int * pi)
{
  int u, i, j, qsize = NUMCITIES;
  for (i = 0; i < NUMCITIES; i++)
  {
    q[i] = i;
    d[i] = INF;
    pi[i] = -1;
  }
  d[s] = 0;
  while (qsize != 0 )
  {
    u = ExtractMin(q, &qsize, d);
/* printf("Extraced %3d; target is %3d\n", u, t); */
    if (u == t) { /* printf("Found target!\n"); */ return; }
    for (j = 0; j < NUMCITIES; j++)
      if (j != u) Relax(u, j, BuildingDistance(u, j), d, pi);
  }
}

void InitGraph()
{
  int i, j;
  for (i = 0; i < NUMCITIES; i++)
  {
    cities[i].x = (float) drand48();
    cities[i].y = (float) drand48();
    for (j = 0; j < NUMCITIES; j++) edges[i][j] = -1;
  } 
}


static int edgecompare(const void * i, const void * j)
{
  if (((edgeto *) i)->w > ((edgeto *) j)->w)  return (1);
  if (((edgeto *) i)->w < ((edgeto *) j)->w)  return (-1);
                                              return (0);
}

void Build(int city1, int city2)
{
  ConstructPath(city1, city2, pi);
  while (city2 != city1)
  {
    if (edges[city2][pi[city2]] < 0)
    {
      edges[city2][pi[city2]] = RealDistance(city2, pi[city2]);
      edges[pi[city2]][city2] = RealDistance(city2, pi[city2]);
    }
    city2 = pi[city2];
  }
}


void BuildShortEdges()
{
  int i, j, bestc, n;
  edgeto * ws;
  ws = (edgeto *) malloc(sizeof(edgeto) * NUMCITIES);
  if (ws == NULL) { printf("malloc error.\n"); exit(2); }
  for (i = 0; i < NUMCITIES; i++)
  {
    for (j = 0; j < NUMCITIES; j++)
    if (j != i)
    {
      ws[j].city = j;
      ws[j].w = sqrt(sqr(cities[j].y - cities[i].y) +
                    sqr(cities[j].x-cities[i].x));
    }
    else { ws[j].city = j; ws[j].w = INF; }
    qsort(ws, NUMCITIES, sizeof(edgeto), edgecompare);
    for (j = 0; j < INITIAL_CONNECTIONS; j++)
      Build(i, ws[j].city);
  }
  free(ws);
}


void BuildViaPaths()
{
  int i, city1, city2;
  for (i = 0; i < NUM_BUILDING_PATHS; i++)
  {
    city1 = lrand48() % NUMCITIES;
    do city2 = lrand48() % NUMCITIES; while (city1 == city2);
    Build(city1, city2);
  }
}

int BuildEdgeGoodList()
{
  int i, j;
  int goods = 0;
  for (i = 0; i < NUMCITIES; i++)
  for (j = 0; j < NUMCITIES; j++)
    edgesgood[i][j] = -1;
  for (i = 0; i < NUMCITIES; i++)
  for (j = i + 1; j < NUMCITIES; j++)
  if (edges[i][j] >= 0)
  {
    edgesgood[i][j] = goods;
    edgesgood[j][i] = goods;
    goods++;
  }
  return goods;
}

void BuildGraph()
{
  int numtries = 0;
  do
  {
    InitGraph();
    BuildShortEdges();
    BuildViaPaths();
    numtries++;
    if (numtries % WARN_TRIES == 0)
    {
      fprintf(stderr, "Tried building a graph %d times without success; still trying...\n", numtries);
      fflush(stderr);
    }
  } while (BuildEdgeGoodList() != NUMGOODS);
}


void AddBidToList(path p, int dummy, double utility)
{
  int i;
  char str[8000];
/*  for (i = 1; i < p.pathlen; i++)
  {
    printf("%d\t", edgesgood[p.path[i]][p.path[i-1]]);
  }
  if (dummy != 0) printf("%d\t", dummy);
  printf("%lf\n", p.cost);
*/
  bids[numbids].value = utility - p.cost;
  bids[numbids].dummy = dummy;
  bids[numbids].numunits = p.capacity;
  bids[numbids].goods = (int *) malloc(sizeof(int) * (p.pathlen-1));
  if (bids[numbids].goods == NULL) { printf("malloc error.\n"); exit(2); }
  bids[numbids].numgoods = p.pathlen-1;
  for (i = 1; i < p.pathlen; i++)
    bids[numbids].goods[i-1] = edgesgood[p.path[i]][p.path[i-1]];
/*   sprintf(str, "bid%04d", numbids);
  DisplayBid(str, bids[numbids]); 
*/
  numbids++;
}


void BidOnPath(path p, int capacity)
{
  int j;
  path tmp;
  if (num_best_paths != MAX_BID_SET_SIZE)
  {
    best_paths[num_best_paths].pathlen = p.pathlen;
    best_paths[num_best_paths].cost = p.cost * capadd;
    best_paths[num_best_paths].capacity = capacity;
    best_paths[num_best_paths].path = malloc(sizeof(int) * NUMCITIES);;
    if (best_paths[num_best_paths].path == NULL)
      { printf("malloc error.\n"); exit(2); }
    memcpy(best_paths[num_best_paths].path, p.path, sizeof(int) * NUMCITIES);
    num_best_paths++;
    j = num_best_paths-1;
    while ((j > 0) && (best_paths[j].cost < best_paths[j-1].cost))
    {
      tmp = best_paths[j];
      best_paths[j] = best_paths[j-1];
      best_paths[j-1] = tmp;
      j--;
    }
  }
  else if (best_paths[MAX_BID_SET_SIZE-1].cost > p.cost)
  {
    memcpy(best_paths[MAX_BID_SET_SIZE-1].path, p.path, sizeof(int) * NUMCITIES);
    best_paths[MAX_BID_SET_SIZE-1].cost = p.cost * capadd;
    best_paths[MAX_BID_SET_SIZE-1].pathlen = p.pathlen;
    best_paths[MAX_BID_SET_SIZE-1].capacity = capacity;
    j = MAX_BID_SET_SIZE-1;
    while ((j > 0) && (best_paths[j].cost < best_paths[j-1].cost))
    {
      tmp = best_paths[j];
      best_paths[j] = best_paths[j-1];
      best_paths[j-1] = tmp;
      j--;
    }
    maxcost = best_paths[MAX_BID_SET_SIZE-1].cost;
  }
}

void FindBids(path p, int dest, int capacity)
{
  int i, j, tmp;
  double curcost;
/* int k;
for (k = 0; k < p.pathlen; k++)
  printf("%lf,%lf ", cities[p.path[k]].x, cities[p.path[k]].y);
printf("... %lf,%lf at %lf <=? %lf\n", cities[dest].x, cities[dest].y, p.cost, maxcost);
*/
  if (p.cost * capadd >= maxcost) return ;
  if (p.path[p.pathlen-1] == dest)
  {
    BidOnPath(p, capacity);
    return ;
  }
  for (i = 0; i < NUMCITIES; i++)
  if (edges[p.path[p.pathlen-1]][i] >= 0)
  if (cap[edgesgood[p.path[p.pathlen-1]][i]] >= capacity)
  {
    for (j = 0; j < p.pathlen; j++)
      if (p.path[j] == i) break;
    if (j == p.pathlen)
    {
      p.path[p.pathlen] = i;
      curcost = p.cost;
      p.cost += edges[p.path[p.pathlen-1]][i];
      tmp = p.pathlen;
      p.pathlen++;
      FindBids(p, dest, capacity);
      p.pathlen = tmp;
      p.cost = curcost;
    }
  }
}

void Bid()
{
  int i, city1, city2, capacity;
  path p;
  double d, cost;
  p.path = malloc(sizeof(int) * NUMCITIES);
  if (p.path == NULL) { printf("malloc error.\n"); exit(2); }
  numbids = 0;
  numdummy = 0;
  while (numbids < NUMBIDS)
  {
    city1 = lrand48() % NUMCITIES;
    do city2 = lrand48() % NUMCITIES; while (city2 == city1);
    capacity = 1 + (lrand48() % MAX_CAP);
    p.path[0] = city1;
    d = (drand48() * (SHIPPING_COST_FACTOR-1)) + 1;
    capadd =  pow((double)capacity, (double)(1 + ADDITIVITY));
    cost = RealDistance(city1, city2) * capadd;
    maxcost = d * cost;
    p.pathlen = 1;
    p.cost = 0;
    num_best_paths = 0;
    FindBids(p, city2, capacity);
    if (num_best_paths > 1)
    {
      for (i = 0; i < num_best_paths; i++)
      {
        AddBidToList(best_paths[i], numdummy + NUMGOODS, maxcost);
        free(best_paths[i].path);
      }
      numdummy++;
    }
    else if (num_best_paths == 1)
    {
      AddBidToList(best_paths[0], 0, maxcost);
      free(best_paths[0].path);
    }
  }
  free(p.path);
}


void PrintBid(bid_type bid)
{
  int i;
  printf("%lf\t", bid.value);
  for (i = 0; i < bid.numgoods; i++)
    printf("%d\t%d\t", bid.goods[i], bid.numunits);
  if (bid.dummy) printf("%d\t1\t", bid.dummy);
  printf("#\n", bid.value);
}

void PrintBids()
{
  int i;
/* int j;
for (i = 0; i < NUMCITIES; i++)
{ 
  for (j = 0; j < NUMCITIES; j++)
    printf("%d ", edgesgood[i][j]);
  printf("\n");
}
*/
  for (i = 0; i < numbids; i++)
  {
    printf("%d\t", i);
    PrintBid(bids[i]);
  }
}

int main(int argc, char * argv [])
{
  int i;
  Initialize();
  BuildGraph();
/*  DisplayGraph("edges", "cities"); */
  Bid();
  printf("goods %d\n", NUMGOODS);
  printf("dummy %d\n", numdummy);
  printf("bids %d\n", numbids);
  printf("maximums");
  for (i = 0; i < NUMGOODS; i++) printf("\t%d", cap[i]);
  printf("\n");
  PrintBids();
  Dispose();
}

