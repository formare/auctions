#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define NUMGOODS 20
#define NUMBIDS 200
#define THREE_PROB 1
#define ADDITIONAL_NEIGHBOR 0.2

#define MAX_GOOD_VALUE 100
#define MAX_SUBSTITUTABLE_BIDS 5
#define ADDITIONAL_LOCATION 0.9
#define JUMP_PROB 0.05
#define ADDITIVITY 0.2
#define DEVIATION 0.5
#define BUDGET_FACTOR 1.5
#define RESALE_FACTOR 0.5
#define S(x) (pow((x), (1+ADDITIVITY)))

typedef struct items {
  int numneigh;
  int * neighbor;
  double c;    /* common value */
  double p;    /* private value */
  double pn;   /* intermediate calculations */
} item;

item location[NUMGOODS];
int nrows, ncols;
int numgoods;

#define LEEWAY MAX_SUBSTITUTABLE_BIDS

typedef struct B {
  int items [NUMGOODS];
  int num_items;
  double c;      /* total common value for this bid */
  double value;  /* value for this bid */
} bid_type_for_generating;

typedef struct bid_type {
  int * goods;
  int numgoods;
  int dummy;
  double value;
} bid_type;

bid_type bids [NUMBIDS + LEEWAY];
int numbids = 0, numdummy = 0;

int IsConnectedLocations(int loc1, int loc2)
{
  int i;
  for (i = 0; i < location[loc1].numneigh; i++)
    if (location[loc1].neighbor[i] == loc2) return 1;
  return 0;
}

void ConnectLocations(int loc1, int loc2)
{
  if (IsConnectedLocations(loc1, loc2)) return;
  location[loc1].neighbor = (int *) realloc(location[loc1].neighbor,
              sizeof(int) * (location[loc1].numneigh+1));
  location[loc2].neighbor = (int *) realloc(location[loc2].neighbor,
              sizeof(int) * (location[loc2].numneigh+1));
  location[loc1].neighbor[location[loc1].numneigh] = loc2;
  location[loc2].neighbor[location[loc2].numneigh] = loc1;
  location[loc1].numneigh++;
  location[loc2].numneigh++;
}

void Connect(int i, int j, int x, int y)
{
  if ((i >= 0) && (i < nrows) &&
     (x >= 0) && (x < nrows) &&
     (j >= 0) && (j < ncols) &&
     (y >= 0) && (y < ncols))
    ConnectLocations(i*ncols+j, x*ncols+y);
}

int IsConnected(int i, int j, int x, int y)
{
  if ((i >= 0) && (i < nrows) &&
     (x >= 0) && (x < nrows) &&
     (j >= 0) && (j < ncols) &&
     (y >= 0) && (y < ncols))
  {
    return IsConnectedLocations(i*ncols+j, x*ncols+y);
  }
  else return 0;
}

void Dispose()
{
  int i, j;
  for (i = 0; i < NUMGOODS; i++)
    free(location[i].neighbor);
}

void InitializeLocations()
{
  int i, j, tmp;
  nrows = (int) floor(sqrt(NUMGOODS));
  ncols = (int) floor(sqrt(NUMGOODS));
  numgoods = nrows * ncols;
  for (i = 0; i < NUMGOODS; i++)
  {
    location[i].numneigh = 0;
    location[i].neighbor = NULL;
  }
  for (i = 0; i < nrows; i++)
  for (j = 0; j < ncols; j++)
  if (!((i > 0) && (j > 0) && (i < nrows - 1) && (j < ncols - 1)))
  {
    Connect(i, j, i+1, j);
    Connect(i, j, i-1, j);
    Connect(i, j, i, j+1);
    Connect(i, j, i, j-1);
  }
  else
  {
    if (drand48() < THREE_PROB)
    {
      tmp = lrand48() % 4;
      switch (tmp)
      {
        case 0:
    Connect(i, j, i-1, j);
    Connect(i, j, i, j+1);
    Connect(i, j, i, j-1);
          break;
        case 1:
    Connect(i, j, i+1, j);
    Connect(i, j, i, j+1);
    Connect(i, j, i, j-1);
          break;
        case 2:
    Connect(i, j, i+1, j);
    Connect(i, j, i-1, j);
    Connect(i, j, i, j-1);
          break;
        case 3:
    Connect(i, j, i+1, j);
    Connect(i, j, i-1, j);
    Connect(i, j, i, j+1);
          break;
      }
    }
    else
    {
      Connect(i, j, i+1, j);
      Connect(i, j, i-1, j);
      Connect(i, j, i, j+1);
      Connect(i, j, i, j-1);
    }
    while (drand48() < ADDITIONAL_NEIGHBOR)
    {
      tmp = lrand48() % 4;
      switch (tmp)
      {
        case 0:
          if (!IsConnected(i-1, j, i, j-1)) Connect(i, j, i-1, j-1);
          break;
        case 1:
          if (!IsConnected(i+1, j, i, j-1)) Connect(i, j, i+1, j-1);
          break;
        case 2:
          if (!IsConnected(i-1, j, i, j+1)) Connect(i, j, i-1, j+1);
          break;
        case 3:
          if (!IsConnected(i+1, j, i, j+1)) Connect(i, j, i+1, j+1);
          break;
      }
    }
  }
}


void DisplayGraph(char * edgefile, char * cityfile)
{
  int i, j;
  FILE * fp;

  fp = fopen(edgefile, "w");
  if (fp == NULL)
  {
    printf("error opening display file for writing\n");
    exit(2);
  }
  for (i = 0; i < NUMGOODS; i++)
  for (j = 0; j < location[i].numneigh; j++)
    fprintf(fp, "%d %d\n%d %d\n\n", i / ncols, i % ncols,
         location[i].neighbor[j] / ncols, location[i].neighbor[j] % ncols);
  fclose(fp);

  fp = fopen(cityfile, "w");
  if (fp == NULL)
  {
    printf("error opening display file for writing\n");
    exit(2);
  }
  for (i = 0; i < nrows; i++)
  for (j = 0; j < ncols; j++)
    fprintf(fp, "%d %d\n", i, j);
  fclose(fp);
}

double Value(bid_type_for_generating b)
{
  int i;
  double total = 0;
  for (i = 0; i < b.num_items; i++)
    total += location[b.items[i]].p + location[b.items[i]].c;
  total += S(b.num_items);
  return total;
}

double CommonValue(bid_type_for_generating b)
{
  int i;
  double total = 0;
  for (i = 0; i < b.num_items; i++)
    total += location[b.items[i]].c;
  return total;
}

int InBidAlready(bid_type_for_generating b, int new_item)
{
  int i;
  for (i = 0; i < b.num_items; i++)
    if (b.items[i] == new_item) return 1;
  return 0;
}

void Add_Good_to_Bundle(bid_type_for_generating * b)
{
  int i, j, new_item;
  double s, prob;
  if (b->num_items == NUMGOODS) return;
  if (drand48() <= JUMP_PROB)
  {
    do new_item = lrand48() % NUMGOODS; while (InBidAlready(*b, new_item));
    b->items[b->num_items] = new_item;
    b->num_items++;
  }
  else
  {
    s = 0;
    for (i = 0; i < NUMGOODS; i++)
      for (j = 0; j < b->num_items; j++)
	if (IsConnectedLocations(i, b->items[j]) &&
	    !InBidAlready(*b, i))
	  s += location[i].pn;
    do
    {
      new_item = lrand48() % NUMGOODS;
      prob = 0;
      for (j = 0; j < b->num_items; j++)
	if (IsConnectedLocations(b->items[j], new_item))
          prob += location[new_item].pn;
      prob /= s;
      /* printf("Item %2d  InBid? %d   prob=%lf\n", new_item, InBidAlready(*b, new_item),prob);
	fflush(stdout); */
    } while (InBidAlready(*b, new_item) || (drand48() > prob));
    b->items[b->num_items] = new_item;
    b->num_items++;
    /* printf("added it...\n");
       fflush(stdout);*/
  }
}

static int bid_compare(const void * a, const void * b)
{
  bid_type_for_generating * bid_a = (bid_type_for_generating *) a;
  bid_type_for_generating * bid_b = (bid_type_for_generating *) b;
  if (bid_a->value > bid_b->value) return -1;
  if (bid_a->value < bid_b->value) return 1;
  return 0;
}

void MakeGeneratedBidIntoRealBid(bid_type_for_generating b, int dummy)
{
  int i;
  bids[numbids].value = b.value;
  bids[numbids].dummy = dummy;
  bids[numbids].numgoods = b.num_items;
  bids[numbids].goods = (int *) malloc(sizeof(int) * b.num_items);
  if (bids[numbids].goods == NULL) { printf("malloc error.\n"); exit(2); }
  memcpy(bids[numbids].goods, b.items, sizeof(int) * b.num_items);
  numbids++;
}

int Identical(bid_type_for_generating a, bid_type_for_generating b)
{
  int i, j, foundit;
  if (a.num_items != b.num_items)
    return 0;
  for (i = 0; i < a.num_items; i++)
  {
    foundit = 0;
    for (j = 0; (j < a.num_items) && !foundit; j++)
      if (a.items[i] == b.items[j]) foundit = 1;
    if (!foundit) return 0;
  }
  return 1;
}

void Bid()
{
  int i, g, one_valid, numsubs, seenbefore, j;
  double total, budget, min_resale_value;
  bid_type_for_generating b, bs[NUMGOODS];
  for (i = 0; i < NUMGOODS; i++)
    location[i].c = drand48() * (MAX_GOOD_VALUE-1) + 1;
  while (numbids < NUMBIDS)
  {
    restart_generation: total = 0;
    for (i = 0; i < NUMGOODS; i++)
    {
      location[i].p = -DEVIATION * MAX_GOOD_VALUE +
                  (drand48() * 2*DEVIATION * MAX_GOOD_VALUE);
      location[i].pn = (location[i].p + DEVIATION * MAX_GOOD_VALUE) /
                2 * DEVIATION * MAX_GOOD_VALUE;
      total += location[i].pn;
    }
    for (i = 0; i < NUMGOODS; i++)
      location[i].pn /= total;
    b.num_items = 0;
    do g = lrand48() % NUMGOODS; while (drand48() > location[g].pn);
    b.items[b.num_items] = g;
    b.num_items++;
    while (drand48() <= ADDITIONAL_LOCATION)
      Add_Good_to_Bundle(&b);
    b.c = CommonValue(b);
    b.value = Value(b);
    if (b.value <= 0) goto restart_generation;
    budget = BUDGET_FACTOR * b.value;
    min_resale_value = RESALE_FACTOR * b.c;
    one_valid = 0;
    for (i = 0; i < b.num_items; i++)
    {
      bs[i].num_items = 1;
      bs[i].items[0] = b.items[i];
      while (bs[i].num_items < b.num_items)
        Add_Good_to_Bundle(&bs[i]);
      bs[i].value = Value(bs[i]);
      bs[i].c = CommonValue(bs[i]);
      if ((bs[i].value >= 0) && (bs[i].value <= budget) &&
	  (bs[i].c >= min_resale_value) && !Identical(b, bs[i]))
	one_valid = 1;
    }
    if (!one_valid)
    {
      MakeGeneratedBidIntoRealBid(b, 0);
      /* printf("Only one valid.\n"); */
    }
    else
    {
      /* printf("Multiple valid.\n");*/
      MakeGeneratedBidIntoRealBid(b, numdummy + NUMGOODS);
      numsubs = 0;
      qsort(bs, b.num_items, sizeof(bid_type_for_generating), bid_compare);
      for (i = 0; i < b.num_items; i++)
      {
        if ((bs[i].value >= 0) && (bs[i].value <= budget) &&
            (bs[i].c >= min_resale_value) && !Identical(b, bs[i]))
	{
          seenbefore = 0;
	  for (j = 0; (j < i) && !seenbefore; j++)
	    if (Identical(bs[j], bs[i])) seenbefore = 1;
	  if (!seenbefore)
	  {
            MakeGeneratedBidIntoRealBid(bs[i], numdummy + NUMGOODS);
            numsubs++;
	  }
	}
        if (numsubs >= MAX_SUBSTITUTABLE_BIDS) break;
      }
      numdummy++;
    }
  }
}

void PrintBid(bid_type bid)
{
  int i;
  printf("%lf\t", bid.value);
  for (i = 0; i < bid.numgoods; i++)
    printf("%d\t", bid.goods[i]);
  if (bid.dummy) printf("%d\t", bid.dummy);
  printf("#\n");
}

void PrintBids()
{
  int i;
  for (i = 0; i < numbids; i++)
  {
    printf("%d\t", i);
    PrintBid(bids[i]);
  }
}

int main(int argc, char * argv[])
{
  srand48(time(NULL));
  InitializeLocations();
  /* DisplayGraph("real_e", "real_c"); */
  Bid();
  printf("goods %d\n", NUMGOODS + numdummy);
  printf("bids %d\n", numbids);
  PrintBids();
  Dispose();
}
