#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/* * Constants & Parameters **************************************** */
#define NUMGOODS 50
#define NUMBIDS 500

#define DEVIATION 0.5
#define PROB_ADDITIONAL_DEADLINE 0.7
#define ADDITIVITY 0.2
#define MAX_LENGTH 10


/* * Variable Definitions ****************************************** */

int numbids, numdummy;

#define LEEWAY NUMGOODS

#define sqr(x) ((x)*(x))
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))

typedef struct bid_type {
  int * goods;
  int numgoods;
  int dummy;
  double value;
} bid_type;

bid_type bids [NUMBIDS + LEEWAY];


void Initialize()
{
  srand48(time(NULL));
}

void AddBidToList(int start, int end, int dummy, double val)
{
  int i;
  bids[numbids].goods = (int *) malloc(sizeof(int) * (end-start+1));
  if (bids[numbids].goods == NULL)
    { printf("malloc error.\n"); exit(2); }
  for (i = 0; i <= end-start; i++)
    bids[numbids].goods[i] = start+i;
  bids[numbids].numgoods = end-start+1;
  bids[numbids].dummy = dummy;
  bids[numbids].value = val;
  numbids++;
}

void Bid()
{
  int l, d_1, cur_max_deadline, new_d, start;
  double dev;
  numbids = 0;
  numdummy = 0;
  while (numbids < NUMBIDS)
  {
    l = 1 + (lrand48() % MAX_LENGTH);
    d_1 = l + lrand48() % (NUMGOODS - l + 1);
/* printf("l = %d; d_1 = %d\n", l, d_1); */
    dev = 1 - DEVIATION + 2 * drand48() * DEVIATION;
    cur_max_deadline = -1;
    new_d = d_1;
    do
    {
      for (start = 0; start < NUMGOODS; start++)
      if ((start + l - 1 <= new_d) && (cur_max_deadline < start + l - 1))
        AddBidToList(start, start+l-1, NUMGOODS + numdummy,
              dev * pow((double)l, 1+ADDITIVITY) * d_1 / new_d);
      cur_max_deadline = new_d;
      if (cur_max_deadline == NUMGOODS - 1) break;
      new_d = cur_max_deadline + 1 + lrand48() % (NUMGOODS - cur_max_deadline - 1);
    } while (drand48() <= PROB_ADDITIONAL_DEADLINE);
    numdummy++;
  }
}

void PrintBid(bid_type bid)
{
  int i;
  printf("%lf\t", bid.value);
  for (i = 0; i < bid.numgoods; i++)
    printf("%d\t", bid.goods[i]);
  if (bid.dummy) printf("%d\t", bid.dummy);
  printf("#\n");
}

void PrintBids()
{
  int i;
  for (i = 0; i < numbids; i++)
  {
    printf("%d\t", i);
    PrintBid(bids[i]);
  }
}

int main(int argc, char * argv [])
{
  Initialize();
  Bid();
  printf("goods %d\n", NUMGOODS+numdummy);
/*  printf("dummy %d\n", numdummy);*/
  printf("bids %d\n", numbids);
  PrintBids();
}

