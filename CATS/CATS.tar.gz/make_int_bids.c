#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double alpha = 100, beta = 0.5;

void PrintUsage(char * exec)
{
  printf("Usage: %s [-h] [-alpha FLOAT] [-beta FLOAT]\n", exec);
  printf("  This program takes a bid file (from standard input) and, for each bid,\n");
  printf("takes the price x offered and changes it to (alpha * x + beta), rounding\n");
  printf("the result to the nearest integer, and outputs the bid file that results\n");
  printf("(to standard output).\n");
  printf("If unspecified, ALPHA defaults to 100 and BETA to 0.5.\n");
  printf("The -h parameter displays this usage message.\n");
  exit(1);
}

void Convert()
{
  int i, numgoods, numbids, bidnum;
  double price;
  char str[8000];                 /* long enough to fit a line */
  if (scanf("goods %d\n", &numgoods) != 1)
  {
    printf("The first line appears not to be goods -- error.\n");
    exit(2);
  }
  if (scanf("bids %d\n", &numbids) != 1)
  {
    printf("The second line appears not to be bids -- error.\n");
    exit(2);
  }
  printf("goods %d\n", numgoods);
  printf("bids %d\n", numbids);
  for (i = 0; i < numbids; i++)
  {
    if (scanf("%d\t%lf\t", &bidnum, &price) != 2)
    {
      printf("The %dth bid line appears not to be legal -- error.\n", i);
      exit(2);
    }
    printf("%d\t%ld\t", bidnum, (long int)rint(alpha*price + beta));
    fgets(str, 8000, stdin);
    printf("%s", str);
  }
}

int main(int argc, char * argv [])
{
  int i;
  for (i = 1; i < argc; i++)
    if (!strcasecmp("-h", argv[i])) PrintUsage(argv[0]);
  for (i = 1; i < argc; i++)
    if (!strcasecmp("-alpha", argv[i]))
    {
      if (i+1 >= argc) PrintUsage(argv[0]);
      alpha = atof(argv[i+1]);
      i++;
    }
    else if (!strcasecmp("-beta", argv[i]))
    {
      if (i+1 >= argc) PrintUsage(argv[0]);
      beta = atof(argv[i+1]);
      i++;
    }
    else PrintUsage(argv[0]);
  Convert();
}

