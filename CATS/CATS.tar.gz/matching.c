#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/* * Constants & Parameters **************************************** */
#define NUMGOODS 20
#define NUMBIDS 100

#define MAX_AIRPORT_PRICE 5
#define MAX_LONGEST_FLIGHT_LENGTH 10
#define DEVIATION 0.5
#define EARLY_TAKEOFF_DEVIATION 1
#define LATE_TAKEOFF_DEVIATION 2
#define EARLY_LAND_DEVIATION 1
#define LATE_LAND_DEVIATION 2
#define DELAY_COEFF 0.9
#define AMOUNT_LATE_COEFF 0.75


#define LONGEST_FLIGHT_LENGTH(x) (min(MAX_LONGEST_FLIGHT_LENGTH, x-1))

/* * Variable Definitions ****************************************** */

int numgoods, numbids, numdummy, num_times;

#define sqr(x) ((x)*(x))
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))

#define NUMCITIES 4
typedef struct { float x, y;} point;
point cities [NUMCITIES];
double edges[NUMCITIES][NUMCITIES];
double cost[NUMCITIES];
double max_l;

#define LEEWAY (EARLY_TAKEOFF_DEVIATION + LATE_TAKEOFF_DEVIATION + 1) * (EARLY_LAND_DEVIATION + LATE_LAND_DEVIATION + 1)

typedef struct bid_type {
/*  int * goods; */ int goods[2];
  int numgoods;
  int dummy;
  double value;
} bid_type;

bid_type bids [NUMBIDS + LEEWAY];


double RealDistance(int city1, int city2)
{
  return sqrt(sqr(cities[city2].x - cities[city1].x) +
             sqr(cities[city2].y - cities[city1].y));
}

void SetupCities()
{
  int i, j;
  cities[0].x = -87.75; cities[0].y = 41.98333333;
  cities[1].x = -77.03333333; cities[1].y =  38.85;
  cities[2].x = -73.783333; cities[2].y = 40.65;
  cities[3].x = -73.8666666; cities[3].y = 40.76666666;
  for (i = 0; i < NUMCITIES; i++)
  for (j = 0; j < NUMCITIES; j++)
    edges[i][j] = -1;
  for (i = 0; i < NUMCITIES; i++)
  for (j = 0; j < NUMCITIES; j++)
    if (i != j)  edges[i][j] = RealDistance(i, j);
  edges[2][3] = -1;
  edges[3][2] = -1;
  max_l = -1;
  for (i = 0; i < NUMCITIES; i++)
  for (j = i+1; j < NUMCITIES; j++)
    max_l = max(max_l, edges[i][j]);
}

void Initialize()
{
  int i;
  srand48(time(NULL));
  SetupCities();
  num_times = floor(NUMGOODS / NUMCITIES);
  numgoods = num_times * NUMCITIES;
  for (i = 0; i < NUMCITIES; i++) cost[i] = drand48() * MAX_AIRPORT_PRICE;
}

void AddBidToList(int good1, int good2, int dummy, double val)
{
  bids[numbids].goods[0] = good1;
  bids[numbids].goods[1] = good2;
  bids[numbids].numgoods = 2;
  bids[numbids].dummy = dummy;
  bids[numbids].value = val;
  numbids++;
}

void Bid()
{
  int city1, city2, min_flight_length, start_time,
       takeoff, land, amount_late, delay;
  double l, dev;
  numbids = 0;
  numdummy = 0;
  while (numbids < NUMBIDS)
  {
    city1 = lrand48() % NUMCITIES;
    do city2 = lrand48() % NUMCITIES; while (!((city1 != city2) && (edges[city1][city2] > 0)));
    l = RealDistance(city1, city2);
    min_flight_length = (int) rint(LONGEST_FLIGHT_LENGTH(num_times) * l/ max_l);
    if (num_times == min_flight_length) start_time = 1;
    else start_time = 1 + lrand48() % (num_times - min_flight_length);
    dev = 1 - DEVIATION + 2 * drand48() * DEVIATION;
    for (takeoff = max(1, start_time - EARLY_TAKEOFF_DEVIATION);
         takeoff <= min(num_times, start_time + LATE_TAKEOFF_DEVIATION);
         takeoff++)
    for (land = takeoff + min_flight_length;
         land <= min(start_time+min_flight_length + LATE_LAND_DEVIATION, num_times);
         land++)
    {
      amount_late = min(land - (start_time + min_flight_length), 0);
      delay = max(land - takeoff - min_flight_length, 0);
      AddBidToList((takeoff - 1) * NUMCITIES + city1,
                   (land - 1) * NUMCITIES + city2,
                   numdummy + numgoods,
                   dev * (cost[city1] + cost[city2]) *
                     pow(DELAY_COEFF, delay) *
                     pow(AMOUNT_LATE_COEFF, amount_late));
    }
    numdummy++;
  }
}

void PrintBid(bid_type bid)
{
  int i;
  printf("%lf\t", bid.value);
  for (i = 0; i < bid.numgoods; i++)
    printf("%d\t", bid.goods[i]);
  if (bid.dummy) printf("%d\t", bid.dummy);
  printf("#\n", bid.value);
}

void PrintBids()
{
  int i;
  for (i = 0; i < numbids; i++)
  {
    printf("%d\t", i);
    PrintBid(bids[i]);
  }
}

int main(int argc, char * argv [])
{
  Initialize();
  Bid();
  printf("goods %d\n", numgoods+numdummy);
/*  printf("dummy %d\n", numdummy); */
  printf("bids %d\n", numbids);
  PrintBids();
}

